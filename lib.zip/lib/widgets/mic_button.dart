import 'package:flutter/material.dart';

class MicButton extends StatelessWidget {
  final bool isListening;
  final VoidCallback onPressed;

  const MicButton({required this.isListening, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(isListening ? Icons.mic_off : Icons.mic),
      label: Text(isListening ? "Stop Listening" : "Start Listening"),
    );
  }
}
