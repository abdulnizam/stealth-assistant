import 'package:flutter/material.dart';

class HistoryPanel extends StatelessWidget {
  final List<String> history;
  final void Function(String)? onTap;

  const HistoryPanel({required this.history, this.onTap});

  @override
  Widget build(BuildContext context) {
    if (history.isEmpty) {
      return Center(child: Text("No history yet."));
    }

    return ListView.builder(
      itemCount: history.length,
      reverse: true, // Show latest on top
      itemBuilder: (context, index) {
        final item = history[index];
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 0),
          child: ListTile(
            title: Text(item),
            onTap: () => onTap?.call(item),
          ),
        );
      },
    );
  }
}