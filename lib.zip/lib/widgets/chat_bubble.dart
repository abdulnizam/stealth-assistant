// lib/widgets/chat_bubble.dart
import 'package:flutter/material.dart';
import 'package:stealth_assistant/widgets/code_block.dart';

class ChatBubble extends StatelessWidget {
  final String message;
  final bool isUser;

  const ChatBubble({super.key, required this.message, required this.isUser});

  @override
  Widget build(BuildContext context) {
    final parts = _splitMessage(message);

    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4.0, horizontal: 8.0),
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          color: isUser
              ? Theme.of(context).colorScheme.primary.withOpacity(0.8)
              : Theme.of(context).colorScheme.surfaceVariant,
          borderRadius: BorderRadius.circular(12.0),
        ),
        child: Column(
          crossAxisAlignment: isUser
              ? CrossAxisAlignment.end
              : CrossAxisAlignment.start,
          children: parts.map((part) {
            if (part['type'] == 'code') {
              return CodeBlock(code: part['text']!);
            } else {
              return Text(
                part['text']!,
                style: const TextStyle(fontSize: 16.0),
              );
            }
          }).toList(),
        ),
      ),
    );
  }

  List<Map<String, String>> _splitMessage(String message) {
    final regex = RegExp(r'```(.*?)```', dotAll: true);
    final matches = regex.allMatches(message);

    if (matches.isEmpty) {
      return [
        {'type': 'text', 'text': message},
      ];
    }

    final List<Map<String, String>> parts = [];
    int currentIndex = 0;

    for (final match in matches) {
      if (match.start > currentIndex) {
        parts.add({
          'type': 'text',
          'text': message.substring(currentIndex, match.start),
        });
      }
      parts.add({'type': 'code', 'text': match.group(1)!.trim()});
      currentIndex = match.end;
    }

    if (currentIndex < message.length) {
      parts.add({'type': 'text', 'text': message.substring(currentIndex)});
    }

    return parts;
  }
}
