import 'package:flutter/material.dart';

class ThemeProvider extends ChangeNotifier {
  bool _isDark = false;
  bool get isDark => _isDark;
  Color _primaryColor = Colors.deepOrange;

  ThemeData get themeData {
    return ThemeData(
      brightness: _isDark ? Brightness.dark : Brightness.light,
      colorScheme: ColorScheme.fromSeed(
        seedColor: _primaryColor,
        brightness: _isDark ? Brightness.dark : Brightness.light,
      ),
      useMaterial3: true,
    );
  }

  Color get selectedColor => _primaryColor;

  void toggleDarkMode() {
    _isDark = !_isDark;
    notifyListeners();
  }

  void updateColor(Color color) {
    _primaryColor = color;
    notifyListeners();
  }
}
