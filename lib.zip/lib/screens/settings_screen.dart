import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final selectedColor = themeProvider.selectedColor;

    return Scaffold(
      appBar: AppBar(title: const Text("Settings")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "🎨 Choose Theme Color",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              children: [
                _buildColorDot(context, Colors.blue, selectedColor),
                _buildColorDot(context, Colors.green, selectedColor),
                _buildColorDot(context, Colors.deepOrange, selectedColor),
                _buildColorDot(context, Colors.purple, selectedColor),
                _buildColorDot(context, Colors.teal, selectedColor),
              ],
            ),
            const SizedBox(height: 30),
            const Divider(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("🌙 Dark Mode"),
                Switch(
                  value: themeProvider.themeData.brightness == Brightness.dark,
                  onChanged: (_) => themeProvider.toggleDarkMode(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildColorDot(
    BuildContext context,
    Color color,
    Color selectedColor,
  ) {
    final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
    final bool isSelected = color.value == selectedColor.value;

    return GestureDetector(
      onTap: () => themeProvider.updateColor(color),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: isSelected ? 44 : 36,
        height: isSelected ? 44 : 36,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(
            color: isSelected ? Colors.black : Colors.grey.shade400,
            width: isSelected ? 3 : 1,
          ),
        ),
        child: isSelected
            ? const Icon(Icons.check, color: Colors.white, size: 20)
            : null,
      ),
    );
  }
}
