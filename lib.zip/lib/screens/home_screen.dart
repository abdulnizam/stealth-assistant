// lib/screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:stealth_assistant/services/speech_service.dart';
import 'package:stealth_assistant/services/api_service.dart';
import 'package:stealth_assistant/widgets/chat_bubble.dart';
import 'package:stealth_assistant/widgets/mic_button.dart';
import 'package:stealth_assistant/providers/theme_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final SpeechService _speechService = SpeechService();
  final List<Map<String, dynamic>> _messages = [];
  final List<String> _history = [];

  bool _isRecording = false;
  int _currentIndex = 0;

  void _toggleRecording() async {
    if (_isRecording) {
      await _speechService.stopListening();
      setState(() {
        _isRecording = false;
      });
    } else {
      await _speechService.startListening((transcript) async {
        setState(() {
          _messages.add({'text': transcript, 'isUser': true});
          _history.add(transcript);
        });
        final response = await ApiService.sendMessage(transcript);
        setState(() {
          _messages.add({'text': response, 'isUser': false});
        });
      });
      setState(() {
        _isRecording = true;
      });
    }
  }

  List<Widget> get _pages => [_buildChatPage(), _buildSettingsPage()];

  Widget _buildChatPage() {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: _messages.length,
            itemBuilder: (context, index) {
              final msg = _messages[index];
              return ChatBubble(message: msg['text'], isUser: msg['isUser']);
            },
          ),
        ),
        MicButton(isListening: _isRecording, onPressed: _toggleRecording),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildSettingsPage() {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final themeColors = <String, Color>{
      'Deep Orange': Colors.deepOrange,
      'Blue': Colors.blue,
      'Green': Colors.green,
      'Purple': Colors.purple,
      'Red': Colors.red,
      'Teal': Colors.teal,
    };
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          "Theme Color",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          children: themeColors.entries.map((entry) {
            final color = entry.value;
            final isSelected = themeProvider.selectedColor == color;
            return GestureDetector(
              onTap: () => themeProvider.updateColor(color),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color,
                  border: Border.all(
                    color: isSelected ? Colors.black : Colors.transparent,
                    width: 3,
                  ),
                ),
                child: isSelected
                    ? const Icon(Icons.check, color: Colors.white, size: 20)
                    : null,
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 30),
        const Text(
          "Dark Mode",
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Switch(
          value: themeProvider.isDark,
          onChanged: (_) => themeProvider.toggleDarkMode(),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    return Scaffold(
      body: SafeArea(child: _pages[_currentIndex]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        selectedItemColor: themeProvider.selectedColor,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.mic), label: 'Home'),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
