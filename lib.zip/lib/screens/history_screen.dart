import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../widgets/history_panel.dart';

class HistoryScreen extends StatelessWidget {
  final List<String> history;

  const HistoryScreen({super.key, required this.history});

  void _copyToClipboard(BuildContext context, String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text("Copied to clipboard")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Transcription History")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: HistoryPanel(
          history: history,
          onTap: (text) => _copyToClipboard(context, text),
        ),
      ),
    );
  }
}
