// lib/services/api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String _apiKey = 'YOUR_OPENAI_API_KEY'; // Replace with your key
  static const String _apiUrl = 'https://api.openai.com/v1/chat/completions';

  static Future<String> sendMessage(String userMessage) async {
    try {
      final res = await http.post(
        Uri.parse(_apiUrl),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $_apiKey',
        },
        body: jsonEncode({
          'model': 'gpt-3.5-turbo',
          'messages': [
            {'role': 'user', 'content': userMessage},
          ],
        }),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final content = data['choices'][0]['message']['content'];
        return content.trim();
      } else {
        print('API error: ${res.body}');
        return '⚠️ Failed to get response';
      }
    } catch (e) {
      print('Error: $e');
      return '⚠️ Error occurred';
    }
  }
}
