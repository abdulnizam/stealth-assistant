import 'package:speech_to_text/speech_to_text.dart' as stt;

class SpeechService {
  final stt.SpeechToText _speech = stt.SpeechToText();

  Future<bool> startListening(Function(String) onResult) async {
    final available = await _speech.initialize();
    if (!available) return false;

    _speech.listen(
      onResult: (val) {
        onResult(val.recognizedWords);
      },
      listenMode: stt.ListenMode.dictation,
    );

    return true;
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }
}
